#!/bin/sh
reset

./SRBMiner-MULTI --algorithm randomx --pool sg.zephyr.herominers.com:1123 --wallet ZEPHYR2v4cTHXEAs46Bt6hP8eqH1aXf6mLoLr9sotNYoLyhLvGCVbF5GaWd5tU3JbCeVRUzHcLmv42AsUfeZo69DapWdbxtVPwR3H --password ams22 --cpu-threads 0 --disable-gpu --log-file ./Logs/log-zepy1.txt